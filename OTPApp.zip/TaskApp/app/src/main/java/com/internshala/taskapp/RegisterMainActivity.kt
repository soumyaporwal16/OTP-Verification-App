package com.internshala.taskapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.TaskExecutors
import com.google.firebase.FirebaseException
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class RegisterMainActivity : AppCompatActivity() {
    lateinit var strotp:String
    lateinit var mobnum:String
    lateinit var inputotp1: EditText
    lateinit var inputotp2:EditText
    lateinit var inputotp3:EditText
    lateinit var inputotp4:EditText
    lateinit var inputotp5:EditText
    lateinit var inputotp6:EditText
    lateinit var buttongetotp:Button
    lateinit var textresend:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_main_activity)

inputotp1=findViewById(R.id.inputotp1)
        inputotp2=findViewById(R.id.inputotp2)
        inputotp3=findViewById(R.id.inputotp3)
        inputotp4=findViewById(R.id.inputotp4)
        inputotp5=findViewById(R.id.inputotp5)
        inputotp6=findViewById(R.id.inputotp6)
        buttongetotp=findViewById(R.id.buttongetotp)
        textresend=findViewById(R.id.textresend)
        mobnum=intent.getStringExtra("mobile").toString()

         strotp = intent.getStringExtra("backendotp").toString()
        buttongetotp.setOnClickListener {

            if(!inputotp1.text.toString().trim().isEmpty() && !inputotp2.text.toString().trim().isEmpty() && !inputotp3.text.toString().trim().isEmpty() && !inputotp4.text.toString().trim().isEmpty() && !inputotp5.text.toString().trim().isEmpty() && !inputotp6.text.toString().trim().isEmpty()){

                var entercodeotp:String=inputotp1.text.toString()+inputotp2.text.toString()+inputotp3.text.toString()+
                        inputotp4.text.toString()+inputotp5.text.toString()+inputotp6.text.toString()

                if(strotp!=null){
                 buttongetotp.setVisibility(View.INVISIBLE)
                    val credential = PhoneAuthProvider.getCredential(strotp, entercodeotp)
                   FirebaseAuth.getInstance().signInWithCredential(credential).addOnCompleteListener(OnCompleteListener<AuthResult>(){
                        fun onComplete(task: Task<AuthResult>){
                            buttongetotp.setVisibility(View.VISIBLE)

                            if(task!=null){
                                val intent = Intent(this@RegisterMainActivity, Dashboard::class.java)
                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                startActivity(intent)
                            }
                            else{
                                Toast.makeText(this@RegisterMainActivity,"Please enter correct otp",Toast.LENGTH_SHORT).show()
                            }

                       }
                   })
                }
                else{
                    Toast.makeText(this@RegisterMainActivity,"Please check internet connection",Toast.LENGTH_SHORT).show()

                }
                Toast.makeText(this@RegisterMainActivity,"otp verify",Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this@RegisterMainActivity,"Please enter correct otp",Toast.LENGTH_SHORT).show()

            }
        }

        numberotpmove()

        textresend.setOnClickListener {
            var phone = "+91" + getIntent().getStringExtra("mobile")
            sendVerificationCode("phone")

        }
        }

   private fun numberotpmove(){
       inputotp1.addTextChangedListener(object : TextWatcher {
           override fun afterTextChanged(s: Editable?) {
           }

           override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
           }

           override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
               if(!s.toString().trim().isEmpty())
                   inputotp2.requestFocus()
           }
       })
       inputotp2.addTextChangedListener(object : TextWatcher {
           override fun afterTextChanged(s: Editable?) {
           }

           override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
           }

           override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
               if(!s.toString().trim().isEmpty())
                   inputotp3.requestFocus()
           }
       })
       inputotp3.addTextChangedListener(object : TextWatcher {
           override fun afterTextChanged(s: Editable?) {
           }

           override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
           }

           override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
               if(!s.toString().trim().isEmpty())
                   inputotp4.requestFocus()
           }
       })
       inputotp4.addTextChangedListener(object : TextWatcher {
           override fun afterTextChanged(s: Editable?) {
           }

           override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
           }

           override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
               if(!s.toString().trim().isEmpty())
                   inputotp5.requestFocus()
           }
       })
       inputotp5.addTextChangedListener(object : TextWatcher {
           override fun afterTextChanged(s: Editable?) {
           }

           override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
           }

           override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
               if(!s.toString().trim().isEmpty())
                   inputotp6.requestFocus()
           }
       })
   }



private fun sendVerificationCode(mobile: String) {

    PhoneAuthProvider.getInstance().verifyPhoneNumber(
            "+91$mobile",
            60,
            TimeUnit.SECONDS,
            TaskExecutors.MAIN_THREAD,
            mCallbacks)
}

private val mCallbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
    override fun onVerificationCompleted(phoneAuthCredential: PhoneAuthCredential) {

    }

    override fun onVerificationFailed(e: FirebaseException) {
        Toast.makeText(this@RegisterMainActivity, e.message, Toast.LENGTH_LONG).show()
    }

    override fun onCodeSent(newbackendotp: String, forceResendingToken: PhoneAuthProvider.ForceResendingToken) {
        strotp=newbackendotp
        Toast.makeText(this@RegisterMainActivity,"Resend Otp scuccessfully",Toast.LENGTH_SHORT).show()
    }
}



}



