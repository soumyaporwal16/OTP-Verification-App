package com.internshala.taskapp

class ForgotActivity {
}