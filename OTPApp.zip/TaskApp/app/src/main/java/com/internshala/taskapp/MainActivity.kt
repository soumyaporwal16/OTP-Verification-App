package com.internshala.taskapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var txtMobNum:TextView
    lateinit var txtPass:TextView

    var mobileNumber="Costum mobnum"
    var password="Custom password"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtMobNum=findViewById(R.id.txtMobnum)
        txtPass=findViewById(R.id.txtPass)

        if (intent!=null){
            mobileNumber=intent.getStringExtra("Mobile").toString()
            txtMobNum.text= mobileNumber

            password=intent.getStringExtra("Pass").toString()
            txtPass.text=password
        }
    }
}