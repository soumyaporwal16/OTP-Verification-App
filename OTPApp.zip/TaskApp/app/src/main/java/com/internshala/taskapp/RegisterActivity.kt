package com.internshala.taskapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.google.android.gms.tasks.TaskExecutors
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken
import com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
import java.util.concurrent.TimeUnit


class RegisterActivity : AppCompatActivity() {
    lateinit var imageView: ImageView
    lateinit var etname: EditText
    lateinit var etemail: EditText
    lateinit var etMobilenum: EditText
    lateinit var etpass: EditText
    lateinit var etconfirmpass: EditText
    lateinit var btnregister: Button
    private val pickImage = 100
    private var imageUri: Uri? = null
    lateinit var phone:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_activity)
        imageView = findViewById(R.id.imageView)
        etname = findViewById(R.id.etname)
        etemail = findViewById(R.id.etemail)
        etMobilenum = findViewById(R.id.etMobilenum)
        etpass = findViewById(R.id.etpass)
        etconfirmpass = findViewById(R.id.etconfirmpass)
        btnregister = findViewById(R.id.btnregister)
        title = "Register Yourself"

        imageView.setOnClickListener {
            val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(gallery, pickImage)
        }


        btnregister.setOnClickListener {
            if (!etMobilenum.text.toString().trim().isEmpty()) {
                if (etMobilenum.text.toString().trim().length == 10) {
                     phone = "+91" + etMobilenum.text.toString()
                    sendVerificationCode(phone)
                } else {
                    Toast.makeText(this@RegisterActivity, "Please Enter correct number", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this@RegisterActivity, "Please Enter number", Toast.LENGTH_SHORT).show()
            }
        }
    }

        override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
            super.onActivityResult(requestCode, resultCode, data)
            if (resultCode == RESULT_OK && requestCode == pickImage) {
                imageUri = data?.data
                imageView.setImageURI(imageUri)
            }
        }

        private fun sendVerificationCode(mobile: String) {

            PhoneAuthProvider.getInstance().verifyPhoneNumber(
                    mobile,
                    60,
                    TimeUnit.SECONDS,
                    TaskExecutors.MAIN_THREAD,
                    mCallbacks)
        }

        private val mCallbacks: OnVerificationStateChangedCallbacks = object : OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(phoneAuthCredential: PhoneAuthCredential) {

            }

            override fun onVerificationFailed(e: FirebaseException) {
                Toast.makeText(this@RegisterActivity, e.message, Toast.LENGTH_LONG).show()
            }

            override fun onCodeSent(backendotp: String, forceResendingToken: ForceResendingToken) {
                intent = Intent(applicationContext, RegisterMainActivity::class.java)
                intent.putExtra("mobile", etMobilenum.text.toString())
                intent.putExtra("backendotp",backendotp)
                startActivity(intent)
            }
        }
    }

